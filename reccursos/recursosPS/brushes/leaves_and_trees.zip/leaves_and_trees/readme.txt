25 brushes, leaves and trees, created in Photoshop CS3.
Free to use both for personal and commercial projects.
By commercial use, I mean you can use them in an website, leaflet, poster, cards, etc. but you can't repackage them and sell them by themselves.
Also I'll be happy if you send me a message and show me what you did with them.

To install the brushes you need to do the following:
1. Unpack the .zip file;
2. Copy the .abr file
3. Paste it in the 'Presets' directory of your main Photoshop program folder, under the subdirectory 'Brushes'. For example, I can find my brushes here:
C:\Program Files\Adobe\Adobe Photoshop CS3\Presets\Brushes
Enjoy!